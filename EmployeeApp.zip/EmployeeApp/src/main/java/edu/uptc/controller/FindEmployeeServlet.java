package edu.uptc.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import edu.uptc.model.Employee;


/**
 * Servlet implementation class UpdatePersonaServlet
 */
@WebServlet("/FindEmployeeServlet")
public class FindEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FindEmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id = Integer.valueOf(request.getParameter("employee_id"));
		if (request.getSession().getAttribute("lista")!=null) {
			ArrayList<Employee> lista =(ArrayList<Employee>)request.getSession().getAttribute("lista");
			Employee emp = new Employee();
			for (Employee empl: lista) {
				if (empl.getEmp_id()==id) {
					String ids= String.valueOf(empl.getEmp_id());
					String name = empl.getEmp_name();
					String email = empl.getEmail_emp();
					String phone = String.valueOf(empl.getPhone_emp());
					request.setAttribute("emp_id", ids);
					request.setAttribute("emp_name", name);
					request.setAttribute("emp_email", email);
					request.setAttribute("emp_phone", phone);
					break;
				}
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/showEmployee.jsp");
			
	        dispatcher.forward(request, response);
		}else {
			PrintWriter out;
		    out = response.getWriter();
	        response.setContentType("text/html");
			out.println("<html>");
			out.println("<head><style>\"/css/empStyle.css\"></style> <title>Respuesta editar empleado</title></head>");
			out.println("<body>");
			out.println("<h1> EMPLOYEE APP</h1>");
			out.println("<h2> No hay empleados registrados!  </h2>");
			out.println("<input type=button onClick=\"parent.location='index.jsp'\"value='Aceptar'>");
			out.println("</body></html>");
		}
		//response.sendRedirect(request.getContextPath() + "/updatePerson.jsp");
	}
	
}
